/**
 *  
 */
package com.roncoo.education.util.base;

/**
 * 基础类
 * 
 * @author @author CHEN
 */
public class BaseBiz extends Base {

}
