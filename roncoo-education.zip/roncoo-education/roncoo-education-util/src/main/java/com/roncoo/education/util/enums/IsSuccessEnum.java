/**
 *  
 */
package com.roncoo.education.util.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author @author CHEN
 */
@Getter
@AllArgsConstructor
public enum IsSuccessEnum {

	SUCCESS(1, "成功", "green"), FAIL(0, "失败", "red");

	private Integer code;

	private String desc;

	private String color;

}
