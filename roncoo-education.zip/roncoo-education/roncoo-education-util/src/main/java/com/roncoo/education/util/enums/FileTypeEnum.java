/**
 *  
 */
package com.roncoo.education.util.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author @author CHEN
 */
@Getter
@AllArgsConstructor
public enum FileTypeEnum {

    LOCAL(0, "本地"), ALIYUN(1, "阿里云"), FDSF(2, "FastDFS"), MINIO(3, "MinIO");

    private Integer code;

    private String desc;

}
