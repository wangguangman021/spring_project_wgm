/**
 *
 */
package com.roncoo.education.util.enums;

/**
 * @author @author CHEN
 */
public enum PlatformEnum {
	COURSE, USER, SYSTEM;
}
