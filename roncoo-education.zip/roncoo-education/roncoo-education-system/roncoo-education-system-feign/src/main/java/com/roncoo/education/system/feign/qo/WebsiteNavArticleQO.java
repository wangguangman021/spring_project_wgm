package com.roncoo.education.system.feign.qo;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 站点导航文章
 *
 * @author LeiLi
 */
@Data
@Accessors(chain = true)
public class WebsiteNavArticleQO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 当前页
     */
    private int pageCurrent;
    /**
     * 每页记录数
     */
    private int pageSize;
    /**
     * 主键
     */
    private Long id;
    /**
     * 创建时间
     */
    private Date gmtCreate;
    /**
     * 修改时间
     */
    private Date gmtModified;
    /**
     * 状态(1有效, 0无效)
     */
    private Integer statusId;
    /**
     * 排序
     */
    private Integer sort;
    /**
     * 导航ID
     */
    private Long navId;
    /**
     * 文章标题
     */
    private String artTitle;
    /**
     * 文章图片
     */
    private String artPic;
    /**
     * 文章描述
     */
    private String artDesc;
}
