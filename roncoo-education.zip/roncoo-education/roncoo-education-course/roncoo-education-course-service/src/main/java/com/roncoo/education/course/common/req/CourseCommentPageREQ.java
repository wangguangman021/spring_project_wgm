package com.roncoo.education.course.common.req;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * 课程信息-分页列出
 *
 * @author @author CHEN
 */
@Data
@Accessors(chain = true)
public class CourseCommentPageREQ implements Serializable {

	private static final long serialVersionUID = 1L;

	/**
	 * 当前页
	 */
	@ApiModelProperty(value = "当前页", required = true)
	private int pageCurrent = 1;
	/**
	 * 每页记录数
	 */
	@ApiModelProperty(value = "每页记录数", required = true)
	private int pageSize = 20;

	private Long id;

	private String courseId;

	private String userId;

	private String content;

	private Date createTime;

	private Date updateTime;
}
