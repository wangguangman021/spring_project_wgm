-- 更新网站设置表地步二维码
update website set weixin='https://cllearning.oss-cn-shenzhen.aliyuncs.com/course/3861ba976cae4ec2a4d8221f54b2c783.png' where id=934374967448227841

-- 视频url
ALTER TABLE course_video ADD url VARCHAR(200) COMMENT 'url';

CREATE TABLE `course_comment`(
                                 `id` BIGINT(64) UNSIGNED AUTO_INCREMENT COMMENT '',
                                 `course_id` VARCHAR(100) NOT NULL,
                                 `user_id` VARCHAR(40) NOT NULL,
                                 `content` VARCHAR(200) NOT NULL,
                                 `score` VARCHAR(200) NOT NULL,
                                 `create_time` VARCHAR(40) NOT NULL,
                                 `update_time` VARCHAR(40) NOT NULL,
                                 PRIMARY KEY ( `id` )
)ENGINE=InnoDB DEFAULT CHARSET=utf8;