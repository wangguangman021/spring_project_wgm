import Vue from 'vue'
import VueDND from 'awe-dnd'

// 拖拽排序
Vue.use(VueDND)