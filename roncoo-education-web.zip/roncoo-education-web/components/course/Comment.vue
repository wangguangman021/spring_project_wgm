<template>
    <div style="font-family: tahoma,'微软雅黑';"> 
        <div style="font-size:18px;margin:5px;margin-left:0px;font-family: tahoma,'微软雅黑';">课程评价：</div>
        分数：<input type="text" v-model="commentScore" placeholder="请输入评价分数（1-10分）" class="commentScore" style="font-family: tahoma,'微软雅黑';width: 160px;height:26px;">&nbsp;分<br/>
        内容：<input type="text" v-model="commentText" placeholder="请输入评价内容！" class="commentText" style="font-family: tahoma,'微软雅黑';width: 200px;height:26px;"> 
        <button @click="commentSave()">评价</button><br/>
        <span>&nbsp;&nbsp;</span>
       <div v-for="(item, index) in list" :key="index" style="font-size:14px;" >
          <div style="position: absolute;">
             <img :src='item.userImage' style="border-radius:50%;width: 40px;aspect-ratio: auto 40 / 40;height: 40px;"/>
          </div>
           <div style="margin-left:46px;font-family: tahoma,'微软雅黑';">
             <div style="font-family: tahoma,'微软雅黑';">昵称：{{item.userName}}</div>
             <div style="font-family: tahoma,'微软雅黑';">评语：{{item.content}}</div>
             <div style="font-family: tahoma,'微软雅黑';">分数：{{item.score}}分</div>
             <div style="font-family: tahoma,'微软雅黑';">评价时间：{{item.time}}</div>
           </div>
            <br/>
       </div>
    </div>
</template>


<script>
  import {commentList, comment} from '~/api/course.js'
  import { mapMutations, mapState } from 'vuex'
  export default {
    name: 'Comment',
    data () {
      return {
        list: []
      }
    },
    mounted () {
      commentList({courseId: this.$parent.courseInfo.id}).then(res => {
        if (res.data.code === 200) {
            console.log(res)
            console.log(res.list)
          this.list = res.data.data.list
        } else {
          console.log('评价获取失败！')
        }
      })
    },
    methods: {
        commentSave(){
            var e1 = this.commentText;
            var e3 = this.commentScore;
            var e2 = this.$parent.courseInfo.id;
            if(e1 == "" || e1==null){
              alert("评价不能为空！")
            }
            comment({courseId: e2,content: e1,score: e3}).then(res => {
            if (res.data.code === 200) {
                window.location.reload();
            } else {
            console.log('评价save失败！')
            }
        })
        }
    }
  }
</script>
<style lang="scss" rel="stylesheet/scss">

</style>
