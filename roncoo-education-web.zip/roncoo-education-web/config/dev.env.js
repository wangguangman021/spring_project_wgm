// 开发环境
export default {
    CLIENT: {
        no: 'lingke', // 接口需要的机构号
        id: 'lkb65617f842ad4c37895a733b8de43cbb', // 接口需要的clientId
        name: '在线教育系统-打造全行业都适用的在线教育系统', // 页面title
        domain: 'localhost', // cookie作用域
        tokenName: 'OSTK', // cookie保存的名称
        mainUrl: 'http://localhost:3000' // 网站域名
    }
}
