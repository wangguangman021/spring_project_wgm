<template>
  <div class="container">
    <div class="text">系统协议：
    </div>
    <div>
      <el-divider></el-divider>
      <div style="background: #f5f5f5;">
        <div class="text">
          <el-alert
            title="系统介绍"
            type="info"
            :closable="false">
            <el-link
                    type="primary"
                    href="https://edu.baidu.net/?sources=os"
                    target="_blank"
                    :underline="false">https://edu.baidu.net/</el-link>
            <li>互动直播、在线点播、智能评卷、在线考试、文库资源、新闻资讯、社区博客、在线问答、报表统计、学习分析等实用的教学功能。</li>
            <li>丰富的资源库功能，灵活的培训方案，多元化的学分激励，强大的组织结构体系，支持多视频云接入。。</li>
            <li>适用于职业教育、企业培训、高校教育、知识付费等各行业的在线教育平台建设需求。</li>
          </el-alert>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
export default {
  name: 'Dashboard',
  methods: {
  },
  computed: {
    ...mapGetters([
      'name'
    ])
  }
}
</script>
<style scoped>
.container {
  margin: 30px;
}
.template {
  background-color: #EBEEF5
}
.bg-purple {
  background: #d3dce6;
}
.bg-purple-light {
    background: #e5e9f2;
  }
.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
.text {
  font-size: 25px;
  line-height: 46px;
}
</style>
